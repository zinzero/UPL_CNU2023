type t = NumV of int
    | BoolV of bool
    | AddrV of int